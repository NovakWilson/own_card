from flask import render_template, redirect
from flask import Flask
import random
import json


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route('/')
@app.route('/index')
def index():
    param = {}
    param['username'] = "Ученик Яндекс.Лицея"
    param['title'] = 'Домашняя страница'
    return render_template('index.html', **param)


@app.route('/odd_even')
def odd_even():
    return render_template('odd_even.html', number=3)


@app.route('/news')
def news():
    with open("news.json", "rt", encoding="utf8") as f:
        news_list = json.loads(f.read())
    print(news_list)
    return render_template('news.html', news=news_list)


@app.route('/lines')
def line():
    return render_template('linee.html', title='очередь')


@app.route('/distribution')
def distribution():
    return render_template('cabins2.html', user_list=['Шон Бин', 'Энди Уир', 'Ваня', 'Петя', 'Саша', 'Кирилл'])


@app.route('/table/<male>/<age>')
def room(male, age):
    return render_template('cabins.html', male=male, age=int(age))


@app.route('/answer')
@app.route('/auto_answer ')
def info():
    return render_template('auto_answer.html', surname='Watny', name='Mark', education='Выше среднего',
                           profession='штурман марсохода', gender='male', motivation='Всегда мечал застрять на марсе',
                           ready='True')


@app.route('/member')
def team():
    with open("templates/members.json", "rt", encoding="utf8") as f:
        news_list = json.loads(f.read())
    member = news_list['team'][random.randint(0, 3)]
    return render_template('own_card.html', member=member)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
